Jeffrey Schachtisck
CS344-Operating Systems
Assignment: Program 3 - smallsh
Date: 05-14-2016
Subject-Readme.txt file

-- Included in zip file
1. readme.txt (this document)
2. smallsh.c

-- To compile
I compiled my code in the eos-class.engr.oregonstate.edu using the following command:
gcc -o smallsh smallsh.class

EOF